<?php
declare(strict_types=1);

// Make a copy named config.php on your hosting account.
// NEVER commit the real config.php to GitHub.
return [
    'bot_token'     => 'PUT_BOT_TOKEN_HERE',
    'admin_user_id' => 0, // Your numeric Telegram user ID
];
